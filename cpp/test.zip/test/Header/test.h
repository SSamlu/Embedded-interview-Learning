#ifndef __TEST_H
#define __TEST_H
#include <stdio.h>

void printTest();



#endif
