/*
* File: sample_file.c
* Author: John Doe
* Date: 24/03/2023
* Description: This is a sample file for demonstrating block-level comment
*/

#include "test.h"

void printTest(){
    printf("Test: hello world\n");
}