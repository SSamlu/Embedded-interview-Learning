#include <stdio.h>
#include "test.h"




int main(int argc, char const *argv[])
{
    printTest();
    return 0;
}
